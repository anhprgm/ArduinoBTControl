package com.arduno.remotebt;

import android.os.Bundle;
import android.util.Log;

import com.arduno.remotebt.databinding.ActivityConfigureLedBinding;

import androidx.appcompat.app.AppCompatActivity;

public class ConfigureLed extends AppCompatActivity {
    private static final String TAG = "HUUDIEN";

    private ActivityConfigureLedBinding binding;
    ConnectedThread connectedThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConfigureLedBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        connectedThread = MyApplication.getApplication().getCurrentConnectedThread();

        binding.bat.setOnClickListener(v -> {
            connectedThread.write("1");
            connectedThread.run();
            Log.d(TAG, "onCreate: " + connectedThread.getValueRead());
        });
        binding.tat.setOnClickListener(v -> {
            connectedThread.write("0");
            connectedThread.run();
            Log.d(TAG, "onCreate: " + connectedThread.getValueRead());
        });

    }
}